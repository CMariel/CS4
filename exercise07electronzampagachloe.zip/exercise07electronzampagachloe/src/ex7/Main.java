package ex7;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author chloezampaga
 */


public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Trainer caitlyn = new Trainer("Caitlyn");
        NPC francis = new NPC("Francis");
        Location forest = new Location("Forest", "Wood");
        FireType dragon = new FireType("Dragon", 400, 50);
        
        caitlyn.inspect(francis);
        caitlyn.inspect(forest);
        caitlyn.inspect(dragon);
        
    }
    
}
