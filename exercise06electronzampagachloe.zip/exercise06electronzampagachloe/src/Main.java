/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author chloezampaga
 */

import java.util.Random;

public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Random random = new Random();
        int randomNumber;
        GrassType bulbasaur = new GrassType("Bulbasaur", 100, 10);
        FireType charmander = new FireType("Charmander", 70, 15);
        WaterType squirtle = new WaterType("Squirtle", 85,10);
        
        //battler & enemy change which is battler per turn
        Monster m = bulbasaur;
        Monster battler = bulbasaur;
        Monster enemy = charmander;
        int iXP = battler.getXP();
        int currXP = battler.getXP();
        int prevLvl = battler.getLevel();
        int currLvl = battler.getLevel();
        boolean attack = false;
        int turnNum = 0;
        while(true){
            randomNumber = random.nextInt();
//            if(battler.getLevel() > 1){
//                
//            }
//            currXP = battler.getXP();
//            currLvl = battler.getLevel();
            boolean turn = false;
//            System.out.println(currXP-iXP);
            if((currXP - iXP > 0 && currXP > 30) || randomNumber % 191 == 0)
            if(randomNumber % 191 == 0){
                int chance = randomNumber % 5;
                System.out.println(chance);
                switch(chance) {
                    case 1:
                        battler.guard();
                    case 3:
                        battler.charge();
                }
                turn = true;
                
            }
            //prevLvl - currLvl > 0 
//            System.out.println(currLvl-prevLvl);
            if(currLvl - prevLvl > 0){
                battler.special();
            }
            if (!turn && !attack){
                battler.attack(enemy);
            }
            iXP = currXP;
            currXP = battler.getXP();
            prevLvl = currLvl;
            currLvl = battler.getLevel();
            turnNum++;
            if(enemy.getHP() <= 0) {
                break;
            }
            enemy = battler;
            if(turnNum % 2 != 0) {
//                battler = enemy;
                enemy = m;
            } else {
//                enemy = battler;
                battler =  m;
            }
//            enemy.attack(battler);
        }
        
//        for(Monster m : Monster.getMonsterList()){
//            Monster battlerA = m;
//            Monster battlerB = m;
//            switch(m.getName()) {
//                case "Bulbasaur":
//                    battlerB = charmander;
////                    System.out.println(Fire);
//                    break;
//                case "Charmander":
//                    battlerB = squirtle;
//                    break;
//                case "Squirtle":
//                    battlerB = bulbasaur;
//                    break;
//            }
//            System.out.println(battlerA.getName());
//            System.out.println(battlerB.getName());
//            System.out.println(battlerA.getName() + " will battle " + battlerB.getName());
//            while(true){
//                battlerA.attack(battlerB);
////                battlerB.charge();
//                if(battlerB.getHP() <= 0) {break;}
//                battlerB.attack(battlerA);
//                if(battlerA.getHP() <= 0) {break;}
//            }
//            System.out.println("\n");
//            battlerA.resetHealth();
//            battlerB.resetHealth();
//        }
    }
    
}
