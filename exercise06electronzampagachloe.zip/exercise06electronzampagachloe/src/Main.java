/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author chloezampaga
 */

import java.util.Random;

public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Random rand = new Random();
        int randomNumber;
        GrassType bulbasaur = new GrassType("Bulbasaur", 200, 10);
        FireType charmander = new FireType("Charmander", 150, 20);
        WaterType squirtle = new WaterType("Squirtle", 175, 15);
        
        for(Monster m : Monster.getMonsterList()){
            Monster attackerA, attackerB, enemy, other;
            other = m;
            switch(m.getName()){
                case "Bulbasaur":
                    other = charmander;
                    System.out.println("Grass vs. Fire \n");
                    break;
                case "Charmander":
                    other = squirtle;
                    System.out.println("Fire vs. Water \n");
                    break;
                case "Squirtle":
                    other = bulbasaur;
                    System.out.println("Water vs. Grass \n");
                    break;
            }
            randomNumber = rand.nextInt();
            Monster first = m;
            if(randomNumber % 2 == 0) {
                attackerA = m;
                enemy = other;
            } else {
                attackerA = other;
                enemy = m;
            }
            first = attackerA;
            attackerB = enemy;
            int turn = 1;
            while(true){
                randomNumber = rand.nextInt();
                if (randomNumber % 10 == 0){
                    if(attackerA.getType().equals("grass" )){
                    attackerA.rest();
                    System.out.println(attackerA.getName() + " rested. It's health is now " + attackerA.getHP() + ".");
                    } else {
                        attackerA.special();
                    }
                } else {
                    attackerA.attack(enemy);
                }
                if(enemy.getHP() == 0){
                    System.out.println(attackerA.getName() + " won the battle.");
                    break;
                }
                if(turn % 2 == 0) {
                    attackerA = enemy;
                    enemy = first;
                } else {
                    attackerA = first;
                    enemy = attackerB;
                }
                turn++;
            }
            attackerA.restoreHealth();
            enemy.restoreHealth();
            System.out.println("\n\n");
        }
    }
    
}
